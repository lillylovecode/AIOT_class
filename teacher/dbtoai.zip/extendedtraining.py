import joblib
import mysql.connector
from sklearn.svm import SVC

# 建立與 MySQL 資料庫的連線
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="aidb"
)

# 使用 cursor 執行 SQL 查詢
cursor = conn.cursor()

# 執行查詢語句，讀取最後200筆資料
query_last_200 = "SELECT temp, humi, target FROM th ORDER BY id DESC LIMIT 200"
cursor.execute(query_last_200)

# 擷取資料
data_last_200 = cursor.fetchall()

# 取得欄位名稱
columns_last_200 = [col[0] for col in cursor.description]

# 將最後200筆資料轉換為特徵(X)和目標值(y)
X_last_200 = []
y_last_200 = []
for row in data_last_200:
    X_last_200.append([row[columns_last_200.index('temp')], row[columns_last_200.index('humi')]])
    y_last_200.append(row[columns_last_200.index('target')])

# 關閉 cursor 和連線
cursor.close()
conn.close()

# 載入已存在的 SVM 模型
existing_model_filename = "SVM_model.pkl"
existing_classifier = joblib.load(existing_model_filename)

# 增益訓練
existing_classifier.fit(X_last_200, y_last_200)

# 儲存增益訓練後的新模型為檔案
model_filename_new = "SVM_model_updated.pkl"  # 新檔案名稱
joblib.dump(existing_classifier, model_filename_new)