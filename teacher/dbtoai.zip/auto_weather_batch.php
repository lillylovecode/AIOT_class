<?php
// 資料庫連線設定
$servername = "localhost"; // 請根據你的設定修改
$username = "root"; // 請填入你的資料庫用戶名
$password = ""; // 請填入你的資料庫密碼
$dbname = "aidb"; // 請填入你的資料庫名稱

// 建立資料庫連線
$conn = new mysqli($servername, $username, $password, $dbname);

// 檢查連線是否成功
if ($conn->connect_error) {
    die("連線失敗: " . $conn->connect_error);
}

// 模擬裝置編號
$device_id = "D001";

// 獲取現在的日期時間
$start_time = new DateTime();

// 生成100筆資料
for ($i = 0; $i < 100; $i++) {
    // 模擬氣溫範圍在20°C至35°C之間
    $temperature = round(mt_rand(2000, 3500) / 100, 2);
    
    // 模擬濕度範圍在40%至80%之間
    $humidity = round(mt_rand(4000, 8000) / 100, 2);
    
    // 產生隨機T或F值
    $target = (mt_rand(0, 1) === 1) ? 'T' : 'F';
    
    // 設定每分鐘產生一筆資料
    $current_time = $start_time->add(new DateInterval('PT1M'));
    
    // 格式化日期時間
    $formatted_time = $current_time->format("Y-m-d H:i:s");
    
    // 準備 SQL 語句
    $sql = "INSERT INTO th (id, datetimes, temp, humi, target) VALUES ('$device_id', '$formatted_time', $temperature, $humidity, '$target')";
    
    // 執行 SQL 語句
    if ($conn->query($sql) !== TRUE) {
        echo "資料插入失敗: " . $conn->error;
    }
}

// 關閉資料庫連線
$conn->close();
?>