import joblib
import mysql.connector

# 建立與 MySQL 資料庫的連線
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="aidb"
)

# 使用 cursor 執行 SQL 查詢
cursor = conn.cursor()

# 執行查詢語句，讀取最新一筆資料
query_latest = "SELECT id, datetimes, temp, humi FROM th ORDER BY id DESC LIMIT 1"
cursor.execute(query_latest)

# 擷取資料
latest_data = cursor.fetchone()

# 顯示id, datatimes, temp, humi
id_val, datetimes_val, temp_val, humi_val = latest_data
print(f"Latest Data - ID: {id_val}, Datetime: {datetimes_val}, Temperature: {temp_val}, Humidity: {humi_val}")

# 取得欄位資料準備進行預測
X_latest = [[temp_val, humi_val]]

# 關閉 cursor 和連線
cursor.close()
conn.close()

# 載入已更新的 SVM 模型
model_filename_updated = "SVM_model_updated.pkl"
classifier_updated = joblib.load(model_filename_updated)

# 預測最新資料的結果
prediction = classifier_updated.predict(X_latest)
print(f"Prediction: {prediction}")