import speech_recognition as sr
r=sr.Recognizer()
r.energy_threshold=4000
while True:
    with sr.Microphone() as source:
        audio=r.listen(source)
    try:
        my_stt=r.recognize_google(audio, language="zh-tw")
        print(my_stt)
    except sr.UnknownValueError:
        print("無法理解")
    except sr.RequestError as e:
        print("Google server出問題")