import cv2
import numpy as np
from keras.models import load_model
import test_db

# 用teachable machine 訓練好的模型載入 keras_model.h5 text 偵測到衛生紙如果>99% 就問是不是衛生紙 如果是 就 -1

# 禁用科學計數法以提高可讀性
np.set_printoptions(suppress=True)

# 加載模型
model = load_model("keras_Model.h5", compile=False)

# 加載標籤
class_names = open("labels.txt", "r").readlines()

# 選擇默認攝像頭，0或1取決於計算機上的攝像頭
camera = cv2.VideoCapture(0)

data = test_db.getAllData()
print(data)

if data:
    # 剩餘量
    pid1_remain = data[0][3]
    pid2_remain = data[1][3]

    # 庫存量水位設定
    pid1_quantity = data[0][2]
    pid2_quantity = data[1][2]

else:
    # 剩餘包裝量
    pid1_remain = 20
    pid2_remain = 20

    # 庫存量水位設定
    pid1_quantity = 5
    pid2_quantity = 5

while True:
    # 獲取攝像頭圖像
    ret, image = camera.read()

    # 將原始圖像調整為(224-高度, 224-寬度)像素
    image = cv2.resize(image, (224, 224), interpolation=cv2.INTER_AREA)

    # 為繪制邊界框創建圖像的副本
    image_copy = np.copy(image)

    # 圖像歸一化
    image = (image / 127.5) - 1

    # 預測模型
    prediction = model.predict(np.expand_dims(image, axis=0))
    index = np.argmax(prediction)
    class_name = class_names[index]
    confidence_score = prediction[0][index]

    # 檢查檢測到的對象是否是棉花棒或衛生紙
    if class_name in ['0 cotton swab\n', '1 tissue\n']:
        # 如果正確率大於99%，提示用户按是或否

        # 衛生紙偵測
        if confidence_score > 0.99 and class_name == '1 tissue\n':
            user_input = input("正確率超過99%，是否為衛生紙？(y/n): ")
            if user_input.lower() == "y":
                # 扣除包裝數量
                pid1_remain -= 1
            elif user_input.lower() == "n":
                pass
            else:
                print("無效的輸入，請輸入 'y' 或 'n'。")

        # 檢查包裝數量是否少於或等於設定庫存數量
        if pid1_remain <= pid1_quantity:
            print("警告：衛生紙不足，低於庫存，請購買更多！")
            break

        # 檢查包裝數量是否少於或等於0
        if pid1_remain == 0:
            print("衛生紙已用完，請購買更多！")
            break

        # 棉棒偵測    
        if confidence_score > 0.99 and class_name == '0 cotton swab\n':
            user_input = input("正確率超過99%，是否為棉花棒？(y/n): ")
            if user_input.lower() == "y":
                # 扣除包裝數量
                pid2_remain -= 1
            elif user_input.lower() == "n":
                pass
            else:
                print("無效的輸入，請輸入 'y' 或 'n'。")

        # 檢查包裝數量是否少於或等於設定庫存數量
        if pid2_remain <= pid2_quantity:
            print("警告：棉花棒不足，低於庫存，請購買更多！")
            break

        # 檢查包裝數量是否少於或等於0
        if pid2_remain == 0:
            print("棉花棒已用完，請購買更多！")
            break  

    # 在窗口中顯示圖像
    cv2.imshow("Webcam Image", image_copy)

    # 打印預測和置信度分數
    print("類別：", class_name[2:], end="")
    print("置信度分數：", str(np.round(confidence_score * 100))[:-2], "%")

    # 監聽鍵盤輸入
    keyboard_input = cv2.waitKey(1)

    # 27是鍵盤上esc鍵的ASCII碼
    if keyboard_input == 27:
        break

# 釋放攝像頭
camera.release()
cv2.destroyAllWindows()

# 顯示剩餘的衛生紙數量
print("剩餘的衛生紙數量：", pid1_remain)

# 更新資料庫
try:
    test_db.updateQuantity(pid1_remain,1)
    test_db.updateQuantity(pid2_remain,2)
    print("資料庫更新成功")
except:
    print("資料庫更新失敗")

