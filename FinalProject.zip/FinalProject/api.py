import mysql.connector
from flask import Flask, request, render_template, redirect, url_for

app = Flask(__name__)

@app.route('/')
def index():
    #MySQL資料庫連接設定
    db = mysql.connector.connect(
        host="localhost",
        user="iot03",
        password="1234",
        database="aidb"
    )
    cursor = db.cursor()
    cursor.execute("SELECT * FROM toilet_paper_inventory")
    result = cursor.fetchall()
    print(result)
    cursor.close()
    db.close()

    if result:
        data = result
    else:
        data = []

    return render_template('index.html', data=data)

@app.route('/add', methods=['POST'])
def add_inventory():
    db = mysql.connector.connect(
        host="localhost",
        user="iot03",
        password="1234",
        database="aidb"
    )
    name = '針筒'
    new_quantity = 10 #request.form['quantity']
    remain = 1 #request.form['remain']
    try:
        cursor = db.cursor()
        sql = "INSERT toilet_paper_inventory(name,quantity,remain) Values ( %s, %s, %s)"
        cursor.execute(sql, (name,new_quantity, remain))
        db.commit()
        print("新增成功")
    except:
        print("新增失敗")
    finally:
        cursor.close()
        return redirect(url_for('index'))

@app.route('/edit', methods=['POST'])
def update_inventory():
    db = mysql.connector.connect(
    host="localhost",
    user="iot03",
    password="1234",
    database="aidb"
    )

    id = request.json['id']
    new_quantity = request.json['quantity']

    cursor = db.cursor()
    update_query = "UPDATE toilet_paper_inventory SET quantity = %s WHERE id = %s"
    cursor.execute(update_query, (new_quantity, id))
    db.commit()
    cursor.close()

    return redirect(url_for('index'))

@app.route('/delete', methods=['GET'])
def delete():
    db = mysql.connector.connect(
    host="localhost",
    user="iot03",
    password="1234",
    database="aidb"
    )

    id = request.args.get('id')

    cursor = db.cursor()
    sql = "DELETE toilet_paper_inventory WHERE id = %s"
    cursor.execute(sql, (id))
    db.commit()
    cursor.close()

    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run()
