# 測試mysql db連接
import mysql.connector
import pandas as pd

def updateQuantity(package_count,id):
    db = mysql.connector.connect(
        db="aidb",
        user="iot03",
        passwd="1234",
        host="localhost",
        port=3306
    )

    cursor = db.cursor()
    update_query = "UPDATE toilet_paper_inventory SET remain = %s where id = %s"
    cursor.execute(update_query, (package_count,id))
    db.commit()
    db.close()


def getAllData():
    db = mysql.connector.connect(
        db="aidb",
        user="iot03",
        passwd="1234",
        host="localhost",
        port=3306
    )

    cursor = db.cursor()

    # 撈取資料
    cursor.execute("SELECT * FROM toilet_paper_inventory")

    # 取回所有資料
    result = cursor.fetchall()

    # 顯示資料
    for i in result:
        print(i)

    # 關閉連線
    db.close()

    return result

